package movies;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "movie")
//@XmlType(propOrder = {"movie_title", "movie_rating", "movie_genre", "age_rating", "release_year", "animated_or_liveAction", "language"})

public class Movie {
    private String movieTitle;
    private double movieRating;
    private String movieGenre;
    private String ageRating;
    private int releaseYear;
    private String animatedOrLiveAction;
    private String language;
 

	public String getMovieTitle() {
		return movieTitle;
	}

	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}

	public double getMovieRating() {
		return movieRating;
	}

	public void setMovieRating(double movieRating) {
		this.movieRating = movieRating;
	}

	public String getMovieGenre() {
		return movieGenre;
	}

	public void setMovieGenre(String movieGenre) {
		this.movieGenre = movieGenre;
	}

	public String getAgeRating() {
		return ageRating;
	}

	public void setAgeRating(String ageRating) {
		this.ageRating = ageRating;
	}

	public int getReleaseYear() {
		return releaseYear;
	}

	public void setReleaseYear(int releaseYear) {
		this.releaseYear = releaseYear;
	}

	public String getAnimatedOrLiveAction() {
		return animatedOrLiveAction;
	}

	public void setAnimatedOrLiveAction(String animatedOrLiveAction) {
		this.animatedOrLiveAction = animatedOrLiveAction;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	@Override
	public String toString() {
		return "Movie [movieTitle=" + movieTitle + ", movieRating=" + movieRating + ", movieGenre=" + movieGenre
				+ ", ageRating=" + ageRating + ", releaseYear=" + releaseYear + ", animatedOrLiveAction="
				+ animatedOrLiveAction + ", language=" + language + "]";
	}



    // Add constructors, getters, and setters here
    
}
