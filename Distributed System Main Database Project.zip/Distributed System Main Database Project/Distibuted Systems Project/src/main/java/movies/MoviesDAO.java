package movies;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public enum MoviesDAO {
    instance;

    // start + end DB connection
    private Connection connection = null;
    private Statement statement = null;
    private ResultSet resultSet = null;
	private static QueryTableModel TableModel = new QueryTableModel();

    public void startConnection() {
        try {
            Class.forName("org.hsqldb.jdbcDriver");
            connection = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/OneDB", "SA", "Passw0rd");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void endConnection() {
        try {
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public QueryTableModel fillTable() {
    	startConnection();
    	try {
    		statement = connection.createStatement();
    		TableModel.refreshFromDB(statement);
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	endConnection();
    	return TableModel;
    }

    // CRUD methods

    public List<Movie> getAllMovies() throws SQLException {
        startConnection();

        List<Movie> movies = new ArrayList<>();
        Movie movie = null;
        String sql = "SELECT * FROM movies";
        PreparedStatement statement = connection.prepareStatement(sql);
        ResultSet resultSet = statement.executeQuery();

        while (resultSet.next()) {
            movie = new Movie();
            String movieTitle = resultSet.getString("movie_title");
            double movieRating = resultSet.getDouble("movie_rating");
            String movieGenre = resultSet.getString("movie_genre");
            String ageRating = resultSet.getString("age_rating");
            int releaseYear = resultSet.getInt("release_year");
            String animatedOrLiveAction = resultSet.getString("animated_or_liveAction");
            String language = resultSet.getString("language");

            movie.setMovieTitle(movieTitle);
            movie.setMovieRating(movieRating);
            movie.setMovieGenre(movieGenre);
            movie.setAgeRating(ageRating);
            movie.setReleaseYear(releaseYear);
            movie.setAnimatedOrLiveAction(animatedOrLiveAction);
            movie.setLanguage(language);

            movies.add(movie);
        }
        endConnection();
        return movies;
    }

    public Movie viewMovieByID(int id) throws SQLException {
        startConnection();

        String sql = "SELECT * FROM movies WHERE movie_id = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, id);
        ResultSet resultSet = statement.executeQuery();

        Movie movie = null;
        if (resultSet.next()) {
            movie = new Movie();
            String movieTitle = resultSet.getString("movie_title");
            double movieRating = resultSet.getDouble("movie_rating");
            String movieGenre = resultSet.getString("movie_genre");
            String ageRating = resultSet.getString("age_rating");
            int releaseYear = resultSet.getInt("release_year");
            String animatedOrLiveAction = resultSet.getString("animated_or_liveAction");
            String language = resultSet.getString("language");

            movie.setMovieTitle(movieTitle);
            movie.setMovieRating(movieRating);
            movie.setMovieGenre(movieGenre);
            movie.setAgeRating(ageRating);
            movie.setReleaseYear(releaseYear);
            movie.setAnimatedOrLiveAction(animatedOrLiveAction);
            movie.setLanguage(language);
        }

        endConnection();
        return movie;
    }

    public void deleteMovieByID(int id) throws SQLException {
        startConnection();
        
        statement = connection.createStatement();

        String sql = "DELETE FROM movies WHERE movie_id = "+id;
        statement.executeUpdate(sql);

        endConnection();
    }
    
    public void createMovie(Movie movie) throws SQLException {
        startConnection();
//      String sql = "INSERT INTO movies (null, '"+movie.getMovieTitle()+"', "+movie.getMovieRating()+",'"+movie.getMovieGenre()+"','"+movie.getAgeRating()+"',"+movie.getReleaseYear()+", '"+movie.getAnimatedOrLiveAction()+"','"+movie.getLanguage()+"')";

        String sql = "INSERT INTO movies (movie_id, movie_title, movie_rating, movie_genre, age_rating, release_year, animated_or_liveAction, language) VALUES (null, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, movie.getMovieTitle());
        statement.setDouble(2, movie.getMovieRating());
        statement.setString(3, movie.getMovieGenre());
        statement.setString(4, movie.getAgeRating());
        statement.setInt(5, movie.getReleaseYear());
        statement.setString(6, movie.getAnimatedOrLiveAction());
        statement.setString(7, movie.getLanguage());

        statement.executeUpdate();
        endConnection();
    }

    public void updateMovie(int id, Movie movie) throws SQLException {
        startConnection();

        String sql = "UPDATE movies SET movie_title = ?, movie_rating = ?, movie_genre = ?, age_rating = ?, release_year = ?, animated_or_liveAction = ?, language = ? WHERE movie_id = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, movie.getMovieTitle());
        statement.setDouble(2, movie.getMovieRating());
        statement.setString(3, movie.getMovieGenre());
        statement.setString(4, movie.getAgeRating());
        statement.setInt(5, movie.getReleaseYear());
        statement.setString(6, movie.getAnimatedOrLiveAction());
        statement.setString(7, movie.getLanguage());
        statement.setInt(8, id);

        statement.executeUpdate();
        endConnection();
    }
}
	
