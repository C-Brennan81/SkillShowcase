package movies;

import javax.swing.*;
import javax.swing.border.Border;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.ArrayList;

public class JDBCMainWindowContent extends JInternalFrame implements ActionListener {
	private static final Object ListAllGenres = null;

	private static final Object AvgRatingByGenre = null;

	private static final JLabel AvgRatingByGenreTF = null;

	String cmd = null;



	private Container content;

	private JPanel detailsPanel;
	private JPanel exportButtonPanel;
	private JScrollPane dbContentsPanel;

	private Border lineBorder;

	private JLabel movieIDLabel = new JLabel("Movie ID: ");
	private JLabel movieTitleLabel = new JLabel("Title: ");
	private JLabel movieRatingLabel = new JLabel("Rating: ");
	private JLabel movieGenreLabel = new JLabel("Genre: ");
	private JLabel ageRatingLabel = new JLabel("Age Rating: ");
	private JLabel releaseYearLabel = new JLabel("Release Year: ");
	private JLabel animatedOrLiveActionLabel = new JLabel("Animated or Live Action: ");
	private JLabel languageLabel = new JLabel("Language: ");

	private JTextField movieIDTF = new JTextField(10);
	private JTextField movieTitleTF = new JTextField(10);
	private JTextField movieRatingTF = new JTextField(10);
	private JTextField movieGenreTF = new JTextField(10);
	private JTextField ageRatingTF = new JTextField(10);
	private JTextField releaseYearTF = new JTextField(10);
	private JTextField animatedOrLiveActionTF = new JTextField(10);
	private JTextField languageTF = new JTextField(10);

	// Add the models to JTables
	// Buttons for inserting, and updating movies
	// also a clear button to clear details panel
	private JButton updateButton = new JButton("Update");
	private JButton insertButton = new JButton("Insert");
	private JButton exportButton = new JButton("Export");
	private JButton deleteButton = new JButton("Delete");
	private JButton clearButton = new JButton("Clear");

	public JDBCMainWindowContent(String aTitle) {
		// setting up the GUI
		super(aTitle, false, false, false, false);
		setEnabled(true);

		MoviesDAO.instance.startConnection();
		// add the 'main' panel to the Internal Frame
		content = getContentPane();
		content.setLayout(null);
		content.setBackground(Color.lightGray);
		lineBorder = BorderFactory.createEtchedBorder(15, Color.red, Color.black);

		// setup details panel and add the components to it
		detailsPanel = new JPanel();
		detailsPanel.setLayout(new GridLayout(9, 2));
		detailsPanel.setBackground(Color.lightGray);
		detailsPanel.setBorder(BorderFactory.createTitledBorder(lineBorder, "CRUD Actions"));

		detailsPanel.add(movieIDLabel);
		detailsPanel.add(movieIDTF);
		detailsPanel.add(movieTitleLabel);
		detailsPanel.add(movieTitleTF);
		detailsPanel.add(movieRatingLabel);
		detailsPanel.add(movieRatingTF);
		detailsPanel.add(movieGenreLabel);
		detailsPanel.add(movieGenreTF);
		detailsPanel.add(ageRatingLabel);
		detailsPanel.add(ageRatingTF);
		detailsPanel.add(releaseYearLabel);
		detailsPanel.add(releaseYearTF);
		detailsPanel.add(animatedOrLiveActionLabel);
		detailsPanel.add(animatedOrLiveActionTF);
		detailsPanel.add(languageLabel);
		detailsPanel.add(languageTF);

		insertButton.setSize(100, 30);
		updateButton.setSize(100, 30);
		exportButton.setSize(100, 30);
		deleteButton.setSize(100, 30);
		clearButton.setSize(100, 30);

		insertButton.setLocation(370, 10);
		updateButton.setLocation(370, 110);
		exportButton.setLocation(370, 160);
		deleteButton.setLocation(370, 60);
		clearButton.setLocation(370, 210);

		insertButton.addActionListener(this);
		updateButton.addActionListener(this);
		exportButton.addActionListener(this);
		deleteButton.addActionListener(this);
		clearButton.addActionListener(this);

		content.add(insertButton);
		content.add(updateButton);
		//content.add(exportButton);
		content.add(deleteButton);
		content.add(clearButton);
		
		JTable TableofDBContents = new JTable(MoviesDAO.instance.fillTable());

		TableofDBContents.setPreferredScrollableViewportSize(new Dimension(900, 300));

		dbContentsPanel = new JScrollPane(TableofDBContents, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		dbContentsPanel.setBackground(Color.lightGray);
		dbContentsPanel.setBorder(BorderFactory.createTitledBorder(lineBorder, "Database Content"));

		detailsPanel.setSize(360, 300);
		detailsPanel.setLocation(3, 0);
		dbContentsPanel.setSize(700, 300);
		dbContentsPanel.setLocation(477, 0);

		content.add(detailsPanel);
		content.add(dbContentsPanel);

		setSize(982, 645);
		setVisible(true);
	}

	public void insertMovies() {
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;
		HttpEntity entity = null;
		try {
			URI uri = new URIBuilder().setScheme("http").setHost("localhost").setPort(8080)
					.setPath("A00275548craigBrennan/rest/movies/create").build();

			HttpPost httpPost = new HttpPost(uri);
			httpPost.setHeader("Accept", "text/plain");

			java.util.List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("movie_id", null));
			params.add(new BasicNameValuePair("movie_title", movieTitleTF.getText()));
			params.add(new BasicNameValuePair("movie_rating", movieRatingTF.getText()));
			params.add(new BasicNameValuePair("movie_genre", movieGenreTF.getText()));
			params.add(new BasicNameValuePair("age_rating", ageRatingTF.getText()));
			params.add(new BasicNameValuePair("release_year", releaseYearTF.getText()));
			params.add(new BasicNameValuePair("animated_or_liveAction", animatedOrLiveActionTF.getText()));
			params.add(new BasicNameValuePair("language", languageTF.getText()));

			httpPost.setEntity(new UrlEncodedFormEntity(params, StandardCharsets.UTF_8));

			httpClient = HttpClients.createDefault();
			httpResponse = httpClient.execute(httpPost);

			MoviesDAO.instance.fillTable();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
	
	public void updateMovies() {
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;
		HttpEntity entity = null;
		try {
			URI uri = new URIBuilder().setScheme("http").setHost("localhost").setPort(8080)
					.setPath("A00275548craigBrennan/rest/movies/update/"+movieIDTF.getText()).build();

			HttpPut httpPut = new HttpPut(uri);
			httpPut.setHeader("Accept", "text/plain");

			java.util.List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("movie_id", null));
			params.add(new BasicNameValuePair("movie_title", movieTitleTF.getText()));
			params.add(new BasicNameValuePair("movie_rating", movieRatingTF.getText()));
			params.add(new BasicNameValuePair("movie_genre", movieGenreTF.getText()));
			params.add(new BasicNameValuePair("age_rating", ageRatingTF.getText()));
			params.add(new BasicNameValuePair("release_year", releaseYearTF.getText()));
			params.add(new BasicNameValuePair("animated_or_liveAction", animatedOrLiveActionTF.getText()));
			params.add(new BasicNameValuePair("language", languageTF.getText()));

			httpPut.setEntity(new UrlEncodedFormEntity(params, StandardCharsets.UTF_8));

			httpClient = HttpClients.createDefault();
			httpResponse = httpClient.execute(httpPut);

			MoviesDAO.instance.fillTable();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
	
	public void deleteMoviesByID() {
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;
		HttpEntity entity = null;
		try {
			URI uri = new URIBuilder().setScheme("http").setHost("localhost").setPort(8080)
					.setPath("A00275548craigBrennan/rest/movies/delete/"+movieIDTF.getText()).build();

			HttpDelete httpDelete = new HttpDelete(uri);
			httpDelete.setHeader("Accept", "text/plain");

			httpClient = HttpClients.createDefault();
			httpResponse = httpClient.execute(httpDelete);

			MoviesDAO.instance.fillTable();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	// event handling
	public void actionPerformed(ActionEvent e) 
	{
		Object target = e.getSource();
		if (target == clearButton) {
			movieIDTF.setText("");
			movieTitleTF.setText("");
			movieRatingTF.setText("");
			movieGenreTF.setText("");
			ageRatingTF.setText("");
			releaseYearTF.setText("");
			animatedOrLiveActionTF.setText("");
			languageTF.setText("");
		}

		if (target == insertButton) {
			System.out.println("Insert Button Clicked!");
			insertMovies();
		}
		if (target == deleteButton) {
			System.out.println("Delete Button Clicked!");
			deleteMoviesByID();
		}
		if (target == updateButton) {
			System.out.println("Update Button Clicked!");
			updateMovies();
		}

		
	}

	// Helper method to write the ResultSet to a file
	private void writeToFile(ResultSet rs) 
	{
		try 
		{
			System.out.println("In writeToFile");
			FileWriter outputFile = new FileWriter("MovieData.csv");
			PrintWriter printWriter = new PrintWriter(outputFile);
			ResultSetMetaData rsmd = rs.getMetaData();
			int numColumns = rsmd.getColumnCount();

			for (int i = 0; i < numColumns; i++) 
			{
				printWriter.print(rsmd.getColumnLabel(i + 1) + ",");
			}
			printWriter.print("\n");
			while (rs.next()) {
				for (int i = 0; i < numColumns; i++)
				{
					printWriter.print(rs.getString(i + 1) + ",");
				}
				printWriter.print("\n");
				printWriter.flush();
			}
			printWriter.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
