package movies;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

@Path("/movies")
public class MovieResource 
{

	//view all
	@GET
	@Produces({MediaType.APPLICATION_XML})
	@Path("/view/all")
	public List<Movie> viewAllMovies() throws SQLException 
	{
	    System.out.println("Fetching all movies");
	    return MoviesDAO.instance.getAllMovies();
	}
	@GET
	@Produces({ MediaType.APPLICATION_XML })
	@Path("/view/{Movie_id}")
	public Movie getMovieByID(@PathParam("Movie_id") String id) throws NumberFormatException, SQLException 
	{
		return MoviesDAO.instance.viewMovieByID(Integer.parseInt(id));
	}
	
	//Create
	
	  @POST
	    @Produces(MediaType.TEXT_PLAIN)
	    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	    @Path("/create")
	    public void createMovie(
		@FormParam("movie_title") String movie_title,
        @FormParam("movie_rating") String movie_rating,
        @FormParam("movie_genre") String movie_genre,
        @FormParam("age_rating") String age_rating,
        @FormParam("release_year") String release_year,
        @FormParam("animated_or_liveAction") String animated_or_liveAction,
        @FormParam("language") String language,
        @Context HttpServletResponse servletResponse) throws SQLException 
	  {

        Movie movie = new Movie();
        movie.setMovieTitle(movie_title);
        movie.setMovieRating(Double.parseDouble(movie_rating));
        movie.setMovieGenre(movie_genre);
        movie.setAgeRating(age_rating);
        movie.setReleaseYear(Integer.parseInt(release_year));
        movie.setAnimatedOrLiveAction(animated_or_liveAction);
        movie.setLanguage(language);
	        
        movie.toString();
        
        MoviesDAO.instance.createMovie(movie);
	    }
	
	  //Update
	  
	  @PUT
	    @Produces(MediaType.TEXT_PLAIN)
	    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	    @Path("/update/{Movie_id}")
	    public void updateMovieByID(
	    		@PathParam("Movie_id") String id,
	    		@FormParam("movie_title") String movie_title,
	    		@FormParam("movie_rating") String movie_rating,    
	    		@FormParam("movie_genre") String movie_genre,
	    		@FormParam("age_rating") String age_rating,
	    		@FormParam("release_year") String release_year,
	    		@FormParam("animated_or_liveAction") String animated_or_liveAction,
	    		@FormParam("language") String language,
	    		@Context HttpServletResponse servletResponse) throws NumberFormatException, SQLException 
	  {

		  Movie movie = new Movie();
	        movie.setMovieTitle(movie_title);
	        movie.setMovieRating(Double.parseDouble(movie_rating));
	        movie.setMovieGenre(movie_genre);
	        movie.setAgeRating(age_rating);
	        movie.setReleaseYear(Integer.parseInt(release_year));
	        movie.setAnimatedOrLiveAction(animated_or_liveAction);
	        movie.setLanguage(language);
	        MoviesDAO.instance.updateMovie(Integer.parseInt(id), movie);
	    }
	  //Delete
	  @DELETE
	  @Produces(MediaType.TEXT_PLAIN)
	  @Path("/delete/{Movie_id}")
	    public void deleteMovieByID(@PathParam("Movie_id") String id) throws NumberFormatException, SQLException 
	  {
	        MoviesDAO.instance.deleteMovieByID(Integer.parseInt(id));
	  }
	}

