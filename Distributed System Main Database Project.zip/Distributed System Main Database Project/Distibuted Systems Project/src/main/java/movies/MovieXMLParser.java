package movies;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public class MovieXMLParser 
{

    boolean inMovies, inMovie, inMovieTitle, inMovieRating, inMovieGenre, inAgeRating,
            inReleaseYear, inAnimatedOrLiveAction, inLanguage = false;

    private Movie movie;
    private List<Movie> movies;
    private String tagValue;

    public List<Movie> startParsing(String input) 
    {
        System.out.println(input);
        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser parser = factory.newPullParser();
            parser.setInput(new StringReader(input));
            processRequest(parser);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return movies;
    }

    public void processRequest(XmlPullParser pullParser) throws XmlPullParserException, IOException 
    {
        int eventType = pullParser.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) 
        {
            if (eventType == XmlPullParser.START_DOCUMENT) 
            {
                System.out.println("START_DOCUMENT");
            } else if (eventType == XmlPullParser.END_DOCUMENT) 
            {
                System.out.println("END_DOCUMENT");
            } else if (eventType == XmlPullParser.START_TAG) 
            {
                processStartTag(pullParser);
            } else if (eventType == XmlPullParser.END_TAG) 
            {
                processEndTag(pullParser);
            } else if (eventType == XmlPullParser.TEXT)
            {
                processText(pullParser);
            }
            eventType = pullParser.next();
        }
    }

    private void processText(XmlPullParser parserEvent) 
    {
        if (inMovieTitle) 
        {
            String s = parserEvent.getText();
            movie.setMovieTitle(s);
        }
        if (inMovieRating) 
        {
            String s = parserEvent.getText();
            movie.setMovieRating(Double.parseDouble(s));
        }
        if (inMovieGenre) 
        {
            String s = parserEvent.getText();
            movie.setMovieGenre(s);
        }
        if (inAgeRating) 
        {
            String s = parserEvent.getText();
            movie.setAgeRating(s);
        }
        if (inReleaseYear) 
        {
            String s = parserEvent.getText();
            movie.setReleaseYear(Integer.parseInt(s));
        }
        if (inAnimatedOrLiveAction) 
        {
            String s = parserEvent.getText();
            movie.setAnimatedOrLiveAction(s);
        }
        if (inLanguage) 
        {
            String s = parserEvent.getText();
            movie.setLanguage(s);
        }
    }

private void processEndTag(XmlPullParser parserEvent)
{
    String endTagName = parserEvent.getName();

    if (endTagName.equalsIgnoreCase("movies")) 
    {
        inMovies = false;
    } else if (endTagName.equalsIgnoreCase("movie")) 
    {
        inMovie = false;
        movies.add(movie);
    } else if (endTagName.equalsIgnoreCase("movie_title")) 
    {
        inMovieTitle = false;
    } else if (endTagName.equalsIgnoreCase("movie_rating")) 
    {
        inMovieRating = false;
    } else if (endTagName.equalsIgnoreCase("movie_genre")) 
    {
        inMovieGenre = false;
    } else if (endTagName.equalsIgnoreCase("age_rating"))
    {
        inAgeRating = false;
    } else if (endTagName.equalsIgnoreCase("release_year")) 
    {
        inReleaseYear = false;
    } else if (endTagName.equalsIgnoreCase("animated_or_liveAction")) 
    {
        inAnimatedOrLiveAction = false;
    } else if (endTagName.equalsIgnoreCase("language")) 
    {
        inLanguage = false;
    }
}

private void processStartTag(XmlPullParser parserEvent) 
{
    String startTagName = parserEvent.getName();

    if (startTagName.equalsIgnoreCase("movies")) 
    {
        inMovies = true;
        movies = new ArrayList<Movie>();
    } else if (startTagName.equalsIgnoreCase("movie")) 
    {
        inMovie = true;
        movie = new Movie();
    } else if (startTagName.equalsIgnoreCase("movie_title"))
    {
        inMovieTitle = true;
    } else if (startTagName.equalsIgnoreCase("movie_rating")) 
    {
        inMovieRating = true;
    } else if (startTagName.equalsIgnoreCase("movie_genre"))
{
        inMovieGenre = true;
    } else if (startTagName.equalsIgnoreCase("age_rating")) 
    {
        inAgeRating = true;
    } else if (startTagName.equalsIgnoreCase("release_year")) 
    {
        inReleaseYear = true;
    } else if (startTagName.equalsIgnoreCase("animated_or_liveAction")) 
    {
        inAnimatedOrLiveAction = true;
    } else if (startTagName.equalsIgnoreCase("language")) 
    {
        inLanguage = true;
    }
}
}
