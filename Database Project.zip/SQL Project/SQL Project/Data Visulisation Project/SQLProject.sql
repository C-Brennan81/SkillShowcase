create database MMORPG;
Use MMORPG;

drop table if exists Player;

Create Table Player
(
PlayerId int,
PlayerName varChar(60),
Password varchar(40),
Region Varchar(20),
CharacterNo int,
AccountLevel int,
Server Varchar (20),
TimePlayed int,
FavouriteClass Varchar(20)
);

select * from Player;

insert into Player values (0001, "LeftTale", "Muggle", "Europe", 3, 12, "Silvervine", 6, "Mage");
insert into Player values (0002, "JumsVibe", "Monkey69", "Europe", 1, 18, "Tellfell", 8, "Assasin");
insert into Player values (0003, "掠奪", "密碼", "Asia", 2, 20, "Redmore", 11, "Knight");
insert into Player values (0004, "Upside", "Flipped", "Australia", 3, 18, "Vustuk", 7, "Archer");
insert into Player values(0005, "Revel", "StingCheese78", "Europe", 2, 12, "Silvervine", 6, "Assasin");


select * from Player;

select Region, count(Region) From Player Where Server = 'Silvervine';